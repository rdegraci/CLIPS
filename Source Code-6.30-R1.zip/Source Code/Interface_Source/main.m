//
//  main.m
//  CLIPSEditor
//
//  Created by Gary Riley on 2/14/06.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **) argv);
}
