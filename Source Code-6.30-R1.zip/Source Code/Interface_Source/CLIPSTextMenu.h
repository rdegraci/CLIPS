/* CLIPSTextMenu */

#import <Cocoa/Cocoa.h>

@interface CLIPSTextMenu : NSObject
{
    IBOutlet NSMenu *textMenu;
}
@end
